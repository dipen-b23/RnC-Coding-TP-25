#include <stdio.h>


int rlargest(int arr[], int n) {

    if (n == 1) {
        return arr[0];
    }

    int largest = rlargest(arr, n - 1);
  
    return (arr[n - 1] > largest) ? arr[n - 1] : largest;
}

int main() {
    int n;
    printf("Enter number of elements in an array: ");
    scanf("%d", &n);

int arr[n];
for (int i = 0; i < n; i++) {
        printf("Enter arr[%d]: ", i);
        scanf("%d", &arr[i]);
    }

 int largest = rlargest(arr, n);

printf("The largest element in the array is: %d\n", largest);

 return 0;
}
