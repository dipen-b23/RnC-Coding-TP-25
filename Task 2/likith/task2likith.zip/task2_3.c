#include<stdio.h>
int main(){
char str[200];
int a=0,e=0,_i=0,o=0,u=0;
printf("enter a string");
scanf("%[^\n]",str);
for(int i=0;str[i]!='\0';i++){
if(str[i]=='a'){
    a++;
}
else if(str[i]=='e'){
    e++;
}
else if(str[i]=='i'){
    _i++;
}
else if(str[i]=='o'){
    o++;
}

else if(str[i]=='u'){
    u++;
}
}
printf("frequency of a is %d\n",a);
printf("frequency of e is %d\n",e);
printf("frequency of i is %d\n",_i);
printf("frequency of o is %d\n",o);
printf("frequency of u is %d\n",u);


    return 0;
}
//2367