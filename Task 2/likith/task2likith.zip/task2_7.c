#include<stdio.h>
#include<string.h>
void rreverse(char str[], int index) {
    int len = strlen(str);
    if(index < len) {
        rreverse(str, index + 1);
        printf("%c", str[index]);
    }
}

int main() {
    char str[100] = "";
    int index = 0;
    printf("Enter a string: ");
    scanf("%[^\n]",str);
    printf("Reversed string is ");
    rreverse(str, index);
    printf("\n");
    return 0;
}



