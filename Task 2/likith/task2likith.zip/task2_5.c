#include <stdio.h>
#include <string.h>

int findSubstring(char str[], char sub[]) {
    int lenStr = strlen(str);
    int lenSub = strlen(sub);

    for (int i = 0; i <= lenStr - lenSub; i++) {
        int j;
        for (j = 0; j < lenSub; j++) {
            if (str[i + j] != sub[j])
                break;
        }
        if (j == lenSub)
            return i; 
    }
    return -1;  
}


void deleteSubstring(char str[], char sub[]) {
    int pos;
    int lenSub = strlen(sub);

    while ((pos = findSubstring(str, sub)) != -1) {
        int lenStr = strlen(str);
        for (int i = pos; i <= lenStr - lenSub; i++) {
            str[i] = str[i + lenSub];
        }
    }

    printf("String after deleting substring: %s\n", str);
}


int main() {
    char str[200], sub[100];
    int choice;

    printf("Enter the main string: ");
    scanf(" %[^\n]", str);

    do {
        printf("\n--- MENU ---\n");
        printf("1. Find Substring\n");
        printf("2. Delete Substring (all occurrences)\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter substring to find: ");
                scanf(" %[^\n]", sub);
                {
                    int pos = findSubstring(str, sub);
                    if (pos != -1)
                        printf("Substring found at index %d\n", pos);
                    else
                        printf("Substring not found!\n");
                }
                break;

            case 2:
                printf("Enter substring to delete: ");
                scanf(" %[^\n]", sub);
                deleteSubstring(str, sub);
                break;

            case 3:
                printf("Exiting program.\n");
                break;

            default:
                printf("Invalid choice! Try again.\n");
        }
    } while (choice != 3);

    return 0;
}