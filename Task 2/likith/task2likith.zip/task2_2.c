#include <stdio.h>


void calcAverage(int rows, int columns, int arr[rows][columns]) {
    for (int i = 0; i < rows; i++) {
        int sum = 0;
        for (int j = 0; j < columns; j++) {
            sum += arr[i][j];
        }
        float avg = (float)sum / columns;
        printf("Average grade of student %d = %.2f\n", i + 1, avg);
    }
}

int main() {
    int rows, columns;

    printf("Enter number of students");
    scanf("%d", &rows);

    printf("Enter number of subjects");
    scanf("%d", &columns);

    int grades[rows][columns];

 
    for (int i = 0; i < rows; i++) {
        printf("\nEnter grades for student %d:\n", i + 1);
        for (int j = 0; j < columns; j++) {
            printf("Subject %d: ", j + 1);
            scanf("%d", &grades[i][j]);
        }
    }

    printf("average of grades is");
    calcAverage(rows, columns, grades);

    return 0;
}


