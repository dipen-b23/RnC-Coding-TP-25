#include<stdio.h>
#include<string.h>
int main(){
char str1[200],str2[200];
int ispalindrome=1;
printf("enter a string");
scanf("%[^\n]",str1);
int count=strlen(str1);
for(int i=count-1,j=0;i>=0;i--,j++){
   str2[j]=str1[i];

}
str2[count]='\0';
for(int k=0;k<count;k++){
    if(str1[k]!=str2[k]){
        ispalindrome=0;
        break;
    }
}
if(ispalindrome==1){
    printf("string is palindrome");

}
else{
    printf("string is not a palindrome");
}
    return 0;
}