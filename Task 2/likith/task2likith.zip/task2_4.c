#include <stdio.h>
#include <string.h>


struct Book {
    char title[100];
    char author[100];
    float price;
};


void swap(struct Book *a, struct Book *b) {
    struct Book temp = *a;
    *a = *b;
    *b = temp;
}


void sortBooks(struct Book books[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (books[j].price > books[j + 1].price) {
                swap(&books[j], &books[j + 1]);
            }
        }
    }
}

int main() {
    int n;
    printf("Enter number of books: ");
    scanf("%d", &n);

    struct Book books[n];

 
    for (int i = 0; i < n; i++) {
        printf("\nEnter details of book %d:\n", i + 1);
        printf("Title: ");
        scanf(" %[^\n]", books[i].title);
        printf("Author: ");
        scanf(" %[^\n]", books[i].author);
        printf("Price: ");
        scanf("%f", &books[i].price);
    }

 
    sortBooks(books, n);

    printf("\nBooks sorted in ascending order of price:\n");
    for (int i = 0; i < n; i++) {
        printf("Title: %s\n", books[i].title);
        printf("Author: %s\n", books[i].author);
        printf("Price: %.2f\n\n", books[i].price);
    }

    return 0;
}